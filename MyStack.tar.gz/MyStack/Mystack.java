package MyStack;

public class Mystack implements StackAndQueue{
    private class Node{
        int value;
        Node next;
        public Node(int value){
            this.value = value;
        }
    }
    Node head;
    public Mystack(){
        head = null;
    }

    @Override
    public boolean push(int value) {
        Node newNode = new Node(value);
        newNode.next = head;
        head = newNode;
        return true;
    }

    @Override
    public int pop() {
        int value = head.value;
        head = head.next;
        return value;
    }

    @Override
    public boolean isFull() {
        return false;
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }
}
