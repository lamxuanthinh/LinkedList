package MyStack;

public interface StackAndQueue {
    public boolean push(int value);
    public int pop();
    public boolean isFull();
    public boolean isEmpty();
}
